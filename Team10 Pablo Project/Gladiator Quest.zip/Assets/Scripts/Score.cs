using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Score
{

    public static int playerScore = 0;

    public static void increaseScore()
    {
        playerScore++;
    }
}
